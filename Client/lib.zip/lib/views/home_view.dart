import 'dart:async'; // Timer 사용 위해 import

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/home_providers.dart'; // Provider import
import '../providers/ranking_provider.dart'; // Ranking Provider import
import 'lobby_view.dart';

class HomeView extends ConsumerStatefulWidget {
  // ConsumerStatefulWidget으로 유지
  const HomeView({super.key});

  @override
  ConsumerState<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends ConsumerState<HomeView> {
  Timer? _timer;
  Duration _currentRemainingTime = Duration.zero; // 화면에 표시될 현재 남은 시간

  @override
  void initState() {
    super.initState();
    // 초기값은 listen 콜백이 fireImmediately:true 로 인해 처리
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _initializeAndStartTimer(Duration newTargetDuration) {
    _timer?.cancel(); // 기존 타이머가 있다면 안전하게 취소

    // 로딩 상태이거나 유효하지 않은 Duration이면 화면에 00:00 또는 --:-- 표시하고 타이머 시작 안 함
    if (newTargetDuration.inDays > 900) {
      // 로딩 상태 값
      print("[HomeView] Provider is loading. Displaying --:--");
      if (mounted) {
        setState(() {
          _currentRemainingTime = newTargetDuration; // 포맷 함수가 "--:--"로 처리
        });
      }
      return;
    }
    if (newTargetDuration.isNegative || newTargetDuration.inSeconds == 0) {
      print(
        "[HomeView] Target duration is zero or negative. Displaying 00:00.",
      );
      if (mounted) {
        setState(() {
          _currentRemainingTime = Duration.zero;
        });
      }
      return;
    }

    // 유효한 새 목표 시간으로 _currentRemainingTime 설정 및 타이머 시작
    print(
      "[HomeView] Starting/Resetting timer with duration: $newTargetDuration",
    );
    if (mounted) {
      setState(() {
        _currentRemainingTime = newTargetDuration;
      });
    }

    _timer = Timer.periodic(const Duration(seconds: 1), (timerInstance) {
      if (!mounted) {
        // 위젯이 dispose된 후라면 타이머 중지
        timerInstance.cancel();
        return;
      }

      if (_currentRemainingTime.inSeconds > 0) {
        setState(() {
          _currentRemainingTime =
              _currentRemainingTime - const Duration(seconds: 1);
        });
      } else {
        timerInstance.cancel();
        print("[HomeView] Timer reached 00:00.");
        // 0초 도달 시 Provider가 새 값을 줄 때까지 00:00으로 유지
        // Provider의 listen 콜백이 새 Duration으로 이 함수를 다시 호출할 것임
        if (mounted) {
          setState(() {
            _currentRemainingTime = Duration.zero;
          });
        }
      }
    });
  }

  String formatDuration(Duration d) {
    if (d.inDays > 900) {
      // 로딩 중일 때 (home_providers.dart 에서 days:999로 설정)
      return "--:--";
    }
    if (d.isNegative || d.inSeconds <= 0) {
      // 0초 이하일 때 (타이머 종료 또는 다음 라운드 없음)
      return "00:00";
    }
    final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return "$minutes:$seconds";
  }

  @override
  Widget build(BuildContext context) {
    final int freePlays = ref.watch(freePlaysProvider);

    // nextAlarmTimeProvider (Firestore 기반 Duration 제공) 값의 변화를 감지
    ref.listen<Duration>(
      nextAlarmTimeProvider,
      (previousDuration, newDuration) {
        print(
          "[HomeView] nextAlarmTimeProvider listen callback: prev=$previousDuration, new=$newDuration",
        );
        // 이전 값과 다를 때만 타이머를 새 값으로 (재)시작
        // (같은 값을 계속 받아서 불필요하게 타이머를 재시작하는 것 방지)
        // 또는 로딩값에서 유효한 값으로 변경될 때
        bool previousWasLoading = previousDuration?.inDays ?? 0 > 900;
        bool newIsValidTime =
            newDuration.inSeconds >= 0 && !(newDuration.inDays > 900);

        if (previousDuration != newDuration ||
            (previousWasLoading && newIsValidTime)) {
          _initializeAndStartTimer(newDuration);
        }
      },
      fireImmediately: true,
    ); // fireImmediately:true 로 설정하여 Provider의 초기값도 listen 콜백으로 받음

    // 화면에 표시할 시간은 _currentRemainingTime (로컬 state) 사용
    final String formattedTime = formatDuration(_currentRemainingTime);

    return Scaffold(
      appBar: AppBar(
        title: const Text('속타왕 홈'),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.local_activity_outlined, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        '남은 무료 플레이: $freePlays회',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.timer_outlined, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        '다음 라운드까지: $formattedTime', // 로컬 State 변수 사용
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ],
                  ),
                ],
              ),
              Column(
                children: [
                  Text(
                    '🏆 실시간 Top 10',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.3,
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: ref
                        .watch(topRankingsProvider)
                        .when(
                          loading:
                              () => const Center(
                                child: CircularProgressIndicator(),
                              ),
                          error: (error, stackTrace) {
                            print(
                              "Error in topRankingsProvider: $error\n$stackTrace",
                            );
                            return Center(
                              child: Text('랭킹을 불러올 수 없습니다.\n$error'),
                            );
                          },
                          data: (List<RankEntry> rankings) {
                            if (rankings.isEmpty) {
                              return const Center(
                                child: Text(
                                  '아직 랭킹 데이터가 없습니다.\n게임을 플레이하여 랭킹에 등록해보세요!',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: Colors.grey),
                                ),
                              );
                            }
                            return ListView.separated(
                              itemCount: rankings.length,
                              itemBuilder: (context, index) {
                                final entry = rankings[index];
                                return ListTile(
                                  dense: true,
                                  leading: Text(
                                    '${index + 1}',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleMedium
                                        ?.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  title: Text(entry.nick),
                                  trailing: Text(
                                    '${entry.score} 점',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                );
                              },
                              separatorBuilder:
                                  (context, index) =>
                                      const Divider(height: 1, thickness: 1),
                            );
                          },
                        ),
                  ),
                ],
              ), // 랭킹 영역 끝
              // --- 하단: 로비 가기 버튼 ---
              ElevatedButton.icon(
                // <--- 여기에 onPressed 와 label 파라미터!
                icon: const Icon(Icons.keyboard_arrow_right),
                label: const Text('로비 가기'), // label 추가
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 32,
                    vertical: 16,
                  ),
                  textStyle: Theme.of(context).textTheme.titleMedium,
                ),
                onPressed: () {
                  // onPressed 추가
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const LobbyView()),
                  );
                },
              ), // 로비 가기 버튼 끝
            ],
          ),
        ),
      ),
    );
  } // build 메소드 끝
}
